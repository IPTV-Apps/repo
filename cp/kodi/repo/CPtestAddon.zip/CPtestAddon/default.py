#############Imports#############
import xbmc , xbmcaddon , xbmcgui , xbmcplugin , base64 , os , re , unicodedata , requests , time , string , sys , urllib , urllib2 , json , urlparse , datetime , zipfile , shutil
from resources . modules import client , control , tools
from resources . ivue import ivuesetup
from datetime import date
from cookielib import CookieJar
import xml . etree . ElementTree as ElementTree
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = 'plugin.video.SMediaAddon'
iIiiiI1IiI1I1 = xbmcaddon . Addon ( id = IiII1IiiIiI1 )
o0OoOoOO00 = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
I11i = 'SMediaAddon'
O0O = control . setting ( 'Username' )
Oo = control . setting ( 'Password' )
if 2 - 2: o0 * i1 * ii1IiI1i % OOooOOo / I11iIi1I / IiiIII111iI
IiII = xbmcgui . Dialog ( )
iI1Ii11111iIi = CookieJar ( )
i1i1II = urllib2 . build_opener ( urllib2 . HTTPCookieProcessor ( iI1Ii11111iIi ) )
i1i1II . addheaders = [ ( 'User-Agent' , 'Mozilla/5.0' ) ]
O0oo0OO0 = int ( sys . argv [ 1 ] )
if 6 - 6: oooO0oo0oOOOO - ooO0oo0oO0 - i111I * II1Ii1iI1i
iiI1iIiI = base64 . decodestring
OOo = ( iiI1iIiI ( 'aHR0cDovL3NtZWRpYS5wYW5lbG1haW5lLmNvbS9Lb2RpL2FwaS8=' ) )
if 1 - 1: IIii11I1 - i1111 - i1IIi11111i / I11i1i11i1I % o0
oo = [ ]
IiII1I1i1i1ii = tools . OPEN_URL ( OOo + ( iiI1iIiI ( 'aWNvbi50eHQ=' ) ) )
IIIII = re . compile ( "icon='([^']*)'" ) . findall ( IiII1I1i1i1ii )
for I1 in IIIII :
 oo = I1
else :
 pass
O0OoOoo00o = ( str ( oo ) ) . replace ( '\/' , '/' )
if 31 - 31: II111iiii + ii1IiI1i . i1IIi11111i
OoOooOOOO = [ ]
IiII1I1i1i1ii = tools . OPEN_URL ( OOo + ( iiI1iIiI ( 'ZmFuYXJ0LnR4dA==' ) ) )
IIIII = re . compile ( "fanart='([^']*)'" ) . findall ( IiII1I1i1i1ii )
for I1 in IIIII :
 OoOooOOOO = I1
else :
 pass
i11iiII = ( str ( OoOooOOOO ) ) . replace ( '\/' , '/' )
if 34 - 34: ooO0oo0oO0 % OoooooooOO / i1IIi . IIii11I1 + O0
I1Ii = [ ]
IiII1I1i1i1ii = tools . OPEN_URL ( OOo + ( iiI1iIiI ( 'ZG5zLnR4dA==' ) ) )
IIIII = re . compile ( "dns='([^']*)'" ) . findall ( IiII1I1i1i1ii )
for I1 in IIIII :
 I1Ii = I1
else :
 pass
o0oOo0Ooo0O = ( str ( I1Ii ) ) . replace ( '\/' , '/' )
if 81 - 81: IiiIII111iI * i1111 * i111I - IIii11I1 - I11iIi1I
OooO0OO = [ ]
IiII1I1i1i1ii = tools . OPEN_URL ( OOo + ( iiI1iIiI ( 'YW5ub3VuY2UudHh0' ) ) )
IIIII = re . compile ( "Announce='([^']*)'" ) . findall ( IiII1I1i1i1ii )
for I1 in IIIII :
 OooO0OO = I1
else :
 pass
iiiIi = ( str ( OooO0OO ) ) . replace ( '[\'' , '' ) . replace ( '\']' , '' )
if 24 - 24: O0 % I11iIi1I + i1IIi + i1IIi11111i + IiiIII111iI
OOoO000O0OO = [ ]
IiII1I1i1i1ii = tools . OPEN_URL ( OOo + ( iiI1iIiI ( 'bWVzc2FnZS50eHQ=' ) ) )
IIIII = re . compile ( "Message='([^']*)'" ) . findall ( IiII1I1i1i1ii )
for I1 in IIIII :
 if O0O in I1 :
  OOoO000O0OO = I1
 else :
  OOoO000O0OO = 'You Have No Private Messages'
else :
 pass
iiI1IiI = ( str ( OOoO000O0OO ) ) . replace ( '[\'' , '' ) . replace ( '\']' , '' )
if 13 - 13: i1 . i11iIiiIii - iIii1I11I1II1 - OOooOOo
ii1I = '%s/enigma2.php?username=%s&password=%s&type=get_live_categories' % ( o0oOo0Ooo0O , O0O , Oo )
OooO0 = '%s/enigma2.php?username=%s&password=%s&type=get_vod_categories' % ( o0oOo0Ooo0O , O0O , Oo )
II11iiii1Ii = '%s/player_api.php?username=%s&password=%s' % ( o0oOo0Ooo0O , O0O , Oo )
OO0o = '%s/panel_api.php?username=%s&password=%s' % ( o0oOo0Ooo0O , O0O , Oo )
Ooo = '%s/live/%s/%s/' % ( o0oOo0Ooo0O , O0O , Oo )
O0o0Oo = '%s/enigma2.php?username=%s&password=%s&type=get_series_categories' % ( o0oOo0Ooo0O , O0O , Oo )
if 78 - 78: iIii1I11I1II1 - II1Ii1iI1i * ii1IiI1i + I11iIi1I + IIii11I1 + IIii11I1
if 11 - 11: IIii11I1 - ii1IiI1i % I11i1i11i1I % IIii11I1 / OOooOOo - ii1IiI1i
o0o0oOOOo0oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/SMediaAddon/resources/catchup' , 'guide.xml' ) )
o0oo0o0O00OO = xbmc . translatePath ( os . path . join ( 'special://home/addons/SMediaAddon/resources/catchup' , 'g' ) )
if 80 - 80: i1IIi
oOOO0o0o = xbmc . translatePath ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/advanced_settings' )
iiI1 = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , 'advancedsettings.xml' ) )
if 19 - 19: i111I + I11i1i11i1I
if 53 - 53: OoooooooOO . i1IIi
def ii1I1i1I ( ) :
 xbmc . executebuiltin ( 'Container.Refresh' )
 if O0O == "" :
  OOoo0O0 = iiiIi1i1I ( )
  oOO00oOO = OoOo ( )
  control . setSetting ( 'Username' , OOoo0O0 )
  control . setSetting ( 'Password' , oOO00oOO )
  xbmc . executebuiltin ( 'Container.Refresh' )
  iI = '%s/enigma2.php?username=%s&password=%s&type=get_vod_categories' % ( o0oOo0Ooo0O , OOoo0O0 , oOO00oOO )
  iI = tools . OPEN_URL ( iI )
  if iI == "" :
   o00O = "Incorrect Login Details"
   OOO0OOO00oo = "Please Re-enter"
   Iii111II = ""
   xbmcgui . Dialog ( ) . ok ( 'Attention' , o00O , OOO0OOO00oo , Iii111II )
   ii1I1i1I ( )
   o00O = "Login Sucsessful"
   OOO0OOO00oo = "Welcome to S Media"
   Iii111II = ( '[COLOR white]%s[/COLOR]' % OOoo0O0 )
   xbmcgui . Dialog ( ) . ok ( 'SMediaAddon' , o00O , OOO0OOO00oo , Iii111II )
   iiii11I ( )
   Ooo0OO0oOO ( 'ADS2' , '' )
   xbmc . executebuiltin ( 'Container.Refresh' )
   ii11i1 ( )
  else :
   o00O = "Login Sucsessful"
   OOO0OOO00oo = "Welcome to S Media"
   Iii111II = ( '[COLOR white]%s[/COLOR]' % OOoo0O0 )
   xbmcgui . Dialog ( ) . ok ( 'SMediaAddon' , o00O , OOO0OOO00oo , Iii111II )
   iiii11I ( )
   Ooo0OO0oOO ( 'ADS2' , '' )
   xbmc . executebuiltin ( 'Container.Refresh' )
   ii11i1 ( )
 else :
  iI = '%s/enigma2.php?username=%s&password=%s&type=get_vod_categories' % ( o0oOo0Ooo0O , O0O , Oo )
  iI = tools . OPEN_URL ( iI )
  if not iI == "" :
   tools . addDir ( 'Service Announcements' , 'url' , 21 , O0OoOoo00o , i11iiII , '' )
   if O0O in iiI1IiI :
    tools . addDir ( '[COLORred]Messages[/COLOR]' , 'url' , 22 , O0OoOoo00o , i11iiII , '' )
   else :
    tools . addDir ( 'Messages' , 'url' , 22 , O0OoOoo00o , i11iiII , '' )
   tools . addDir ( 'Account Information' , 'url' , 6 , O0OoOoo00o , i11iiII , '' )
   tools . addDir ( 'Live TV' , 'live' , 1 , O0OoOoo00o , i11iiII , '' )
   if xbmc . getCondVisibility ( 'System.HasAddon(pvr.iptvsimple)' ) or xbmc . getCondVisibility ( 'System.HasAddon(script.ivueguide)' ) :
    tools . addDir ( 'TV Guide' , 'pvr' , 7 , O0OoOoo00o , i11iiII , '' )
   tools . addDir ( 'Movies' , 'vod' , 3 , O0OoOoo00o , i11iiII , '' )
   if 29 - 29: IiiIII111iI % o0 + I11i1i11i1I / I11iIi1I + ooO0oo0oO0 * I11iIi1I
   tools . addDir ( 'TV Shows' , O0o0Oo , 24 , O0OoOoo00o , i11iiII , '' )
   tools . addDir ( 'Catchup TV' , 'url' , 12 , O0OoOoo00o , i11iiII , '' )
   if 42 - 42: II1Ii1iI1i + oooO0oo0oOOOO
   tools . addDir ( 'Search' , 'url' , 5 , O0OoOoo00o , i11iiII , '' )
   tools . addDir ( 'Settings' , 'url' , 8 , O0OoOoo00o , i11iiII , '' )
   tools . addDir ( 'Extras' , 'url' , 16 , O0OoOoo00o , i11iiII , '' )
def ii11i1 ( ) :
 tools . addDir ( 'Service Announcements' , 'url' , 21 , O0OoOoo00o , i11iiII , '' )
 if O0O in iiI1IiI :
  tools . addDir ( '[COLORred]Messages[/COLOR]' , 'url' , 22 , O0OoOoo00o , i11iiII , '' )
 else :
  tools . addDir ( 'Messages' , 'url' , 22 , O0OoOoo00o , i11iiII , '' )
 tools . addDir ( 'Account Information' , 'url' , 6 , O0OoOoo00o , i11iiII , '' )
 tools . addDir ( 'Live TV' , 'live' , 1 , O0OoOoo00o , i11iiII , '' )
 if xbmc . getCondVisibility ( 'System.HasAddon(pvr.iptvsimple)' ) :
  tools . addDir ( 'TV Guide' , 'pvr' , 7 , O0OoOoo00o , i11iiII , '' )
 tools . addDir ( 'Movies' , 'vod' , 3 , O0OoOoo00o , i11iiII , '' )
 if 76 - 76: i1IIi11111i - ii1IiI1i
 tools . addDir ( 'TV Shows' , O0o0Oo , 24 , O0OoOoo00o , i11iiII , '' )
 tools . addDir ( 'Catchup TV' , 'url' , 12 , O0OoOoo00o , i11iiII , '' )
 if 70 - 70: I11i1i11i1I
 tools . addDir ( 'Search' , '' , 5 , O0OoOoo00o , i11iiII , '' )
 tools . addDir ( 'Settings' , 'url' , 8 , O0OoOoo00o , i11iiII , '' )
 tools . addDir ( 'Extras' , 'url' , 16 , O0OoOoo00o , i11iiII , '' )
 if 61 - 61: IiiIII111iI . IiiIII111iI
def IIi1I1Ii11iI ( url ) :
 if 39 - 39: i1111 - II111iiii * ii1IiI1i % I11iIi1I * II111iiii % II111iiii
 open = tools . OPEN_URL ( ii1I )
 OoOOOOO = tools . regex_get_all ( open , '<channel>' , '</channel>' )
 for iIi1i111II in OoOOOOO :
  OoOO00O = tools . regex_from_to ( iIi1i111II , '<title>' , '</title>' )
  OoOO00O = base64 . b64decode ( OoOO00O )
  oOOoO0O0O0 = tools . regex_from_to ( iIi1i111II , '<playlist_url>' , '</playlist_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
  tools . addDir ( OoOO00O , oOOoO0O0O0 , 2 , O0OoOoo00o , i11iiII , '' )
  if 86 - 86: o0 + II1Ii1iI1i % i11iIiiIii * oooO0oo0oOOOO . I11i1i11i1I * i111I
def i1I11i1iI ( url ) :
 open = tools . OPEN_URL ( url )
 OoOOOOO = tools . regex_get_all ( open , '<channel>' , '</channel>' )
 for iIi1i111II in OoOOOOO :
  OoOO00O = tools . regex_from_to ( iIi1i111II , '<title>' , '</title>' )
  OoOO00O = base64 . b64decode ( OoOO00O )
  xbmc . log ( str ( OoOO00O ) )
  try :
   OoOO00O = re . sub ( '\[.*?min ' , '-' , OoOO00O )
  except :
   pass
  I1ii1Ii1 = tools . regex_from_to ( iIi1i111II , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
  oOOoO0O0O0 = tools . regex_from_to ( iIi1i111II , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
  iii11 = tools . regex_from_to ( iIi1i111II , '<description>' , '</description>' )
  tools . addDir ( OoOO00O , oOOoO0O0O0 , 4 , I1ii1Ii1 , i11iiII , base64 . b64decode ( iii11 ) )
  if 68 - 68: ii1IiI1i
  if 35 - 35: ii1IiI1i - IIii11I1 / i1 / OOooOOo
def I1i1IiI1 ( url ) :
 if url == "vod" :
  open = tools . OPEN_URL ( OooO0 )
 else :
  open = tools . OPEN_URL ( url )
 OoOOOOO = tools . regex_get_all ( open , '<channel>' , '</channel>' )
 for iIi1i111II in OoOOOOO :
  if '<playlist_url>' in open :
   OoOO00O = tools . regex_from_to ( iIi1i111II , '<title>' , '</title>' )
   oOOoO0O0O0 = tools . regex_from_to ( iIi1i111II , '<playlist_url>' , '</playlist_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
   tools . addDir ( str ( base64 . b64decode ( OoOO00O ) ) . replace ( '?' , '' ) , oOOoO0O0O0 , 3 , O0OoOoo00o , i11iiII , '' )
  else :
   if xbmcaddon . Addon ( ) . getSetting ( 'meta' ) == 'true' :
    try :
     OoOO00O = tools . regex_from_to ( iIi1i111II , '<title>' , '</title>' )
     OoOO00O = base64 . b64decode ( OoOO00O )
     I1ii1Ii1 = tools . regex_from_to ( iIi1i111II , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     url = tools . regex_from_to ( iIi1i111II , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     iii11 = tools . regex_from_to ( iIi1i111II , '<description>' , '</description>' )
     iii11 = base64 . b64decode ( iii11 )
     oO0o0OOOO = tools . regex_from_to ( iii11 , 'PLOT:' , '\n' )
     O0O0OoOO0 = tools . regex_from_to ( iii11 , 'CAST:' , '\n' )
     iiiI1I11i1 = tools . regex_from_to ( iii11 , 'RATING:' , '\n' )
     IIi1i11111 = tools . regex_from_to ( iii11 , 'RELEASEDATE:' , '\n' ) . replace ( ' ' , '-' )
     IIi1i11111 = re . compile ( '-.*?-.*?-(.*?)-' , re . DOTALL ) . findall ( IIi1i11111 )
     ooOO00O00oo = tools . regex_from_to ( iii11 , 'DURATION_SECS:' , '\n' )
     I1ii11iI = tools . regex_from_to ( iii11 , 'GENRE:' , '\n' )
     tools . addDirMeta ( str ( OoOO00O ) . replace ( '[/COLOR].' , '.[/COLOR]' ) , url , 4 , I1ii1Ii1 , i11iiII , oO0o0OOOO , str ( IIi1i11111 ) . replace ( "['" , "" ) . replace ( "']" , "" ) , str ( O0O0OoOO0 ) . split ( ) , iiiI1I11i1 , ooOO00O00oo , I1ii11iI )
    except : pass
    xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
   else :
    OoOO00O = tools . regex_from_to ( iIi1i111II , '<title>' , '</title>' )
    OoOO00O = base64 . b64decode ( OoOO00O )
    I1ii1Ii1 = tools . regex_from_to ( iIi1i111II , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    url = tools . regex_from_to ( iIi1i111II , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    iii11 = tools . regex_from_to ( iIi1i111II , '<description>' , '</description>' )
    tools . addDir ( OoOO00O , url , 4 , I1ii1Ii1 , i11iiII , base64 . b64decode ( iii11 ) )
    if 14 - 14: OOooOOo / i1111 . OOooOOo . i111I % ii1IiI1i * i111I
    if 16 - 16: OOooOOo . I11i1i11i1I + i11iIiiIii
    if 38 - 38: i1111 * ooO0oo0oO0 . I11iIi1I
def ooo0OO ( title , msg ) :
 class O0ii1ii1ii ( xbmcgui . WindowXMLDialog ) :
  def onInit ( self ) :
   self . title = 101
   self . msg = 102
   self . scrollbar = 103
   self . okbutton = 201
   self . showdialog ( )
   if 91 - 91: i1111
  def showdialog ( self ) :
   self . getControl ( self . title ) . setLabel ( title )
   self . getControl ( self . msg ) . setText ( msg )
   self . setFocusId ( self . scrollbar )
   if 15 - 15: II111iiii
  def onClick ( self , controlId ) :
   if ( controlId == self . okbutton ) :
    self . close ( )
    if 18 - 18: i11iIiiIii . i1IIi % OoooooooOO / O0
  def onAction ( self , action ) :
   if action == ACTION_PREVIOUS_MENU : self . close ( )
   elif action == ACTION_NAV_BACK : self . close ( )
   if 75 - 75: OOooOOo % I11iIi1I % I11iIi1I . i1IIi11111i
 III1iII1I1ii = O0ii1ii1ii ( "Textbox.xml" , iIiiiI1IiI1I1 . getAddonInfo ( 'path' ) , 'DefaultSkin' , title = title , msg = msg )
 III1iII1I1ii . doModal ( )
 del III1iII1I1ii
 if 61 - 61: II111iiii
def O0OOO ( ) :
 ooo0OO ( '[COLOR orangered]Service Announcements[/COLOR]' , '[COLOR limegreen]' + iiiIi + '[/COLOR]' )
def II11iIiIIIiI ( ) :
 ooo0OO ( '[COLOR orangered]Just For You[/COLOR]' , '[COLOR limegreen]' + iiI1IiI + '[/COLOR]' )
 if 67 - 67: i1IIi11111i . IIii11I1 . O0
def IIIIiiII111 ( ) :
 if os . path . exists ( o0OoOoOO00 ) == True :
  for OOoOoo , oO0000OOo00 , iiIi1IIiIi in os . walk ( o0OoOoOO00 ) :
   oOO00Oo = 0
   oOO00Oo += len ( iiIi1IIiIi )
   if oOO00Oo > 0 :
    if 6 - 6: oooO0oo0oOOOO
    if 68 - 68: OOooOOo - ii1IiI1i
    for IIi in iiIi1IIiIi :
     try :
      os . unlink ( os . path . join ( OOoOoo , IIi ) )
     except :
      pass
    for ooOOoooooo in oO0000OOo00 :
     try :
      shutil . rmtree ( os . path . join ( OOoOoo , ooOOoooooo ) )
     except :
      pass
      if 1 - 1: i1 / I11iIi1I % IIii11I1 * i1111 . i11iIiiIii
      if 2 - 2: IiiIII111iI * i111I - iIii1I11I1II1 + o0 . oooO0oo0oOOOO % IIii11I1
 IiII = xbmcgui . Dialog ( )
 IiII . ok ( I11i , "Cache Cleared Successfully!" )
 xbmc . executebuiltin ( "Container.Refresh()" )
 if 92 - 92: IIii11I1
def IIiIiiIi ( ) :
 xbmc . executebuiltin ( 'RecursiveSlideShow(http://someurl/fixtures/1.png)' )
 if 51 - 51: i111I + IIii11I1 % iIii1I11I1II1 / oooO0oo0oOOOO / ooO0oo0oO0 % OoooooooOO
 if 78 - 78: II1Ii1iI1i % i1IIi11111i + IiiIII111iI
def OOooOoooOoOo ( url ) :
 open = tools . OPEN_URL ( url )
 OoOOOOO = tools . regex_get_all ( open , '<channel>' , '</channel>' )
 for iIi1i111II in OoOOOOO :
  if '<playlist_url>' in open :
   OoOO00O = tools . regex_from_to ( iIi1i111II , '<title>' , '</title>' )
   iii11 = tools . regex_from_to ( iIi1i111II , '<description>' , '</description>' )
   oOOoO0O0O0 = tools . regex_from_to ( iIi1i111II , '<playlist_url>' , '</playlist_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
   tools . addDir ( str ( base64 . b64decode ( OoOO00O ) ) . replace ( '?' , '' ) , oOOoO0O0O0 , 24 , O0OoOoo00o , i11iiII , ( base64 . b64decode ( iii11 ) ) )
  else :
   if xbmcaddon . Addon ( ) . getSetting ( 'meta' ) == 'true' :
    try :
     OoOO00O = tools . regex_from_to ( iIi1i111II , '<title>' , '</title>' )
     OoOO00O = base64 . b64decode ( OoOO00O )
     I1ii1Ii1 = tools . regex_from_to ( iIi1i111II , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     url = tools . regex_from_to ( iIi1i111II , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     iii11 = tools . regex_from_to ( iIi1i111II , '<description>' , '</description>' )
     iii11 = base64 . b64decode ( iii11 )
     oO0o0OOOO = tools . regex_from_to ( iii11 , 'PLOT:' , '\n' )
     O0O0OoOO0 = tools . regex_from_to ( iii11 , 'CAST:' , '\n' )
     iiiI1I11i1 = tools . regex_from_to ( iii11 , 'RATING:' , '\n' )
     IIi1i11111 = tools . regex_from_to ( iii11 , 'RELEASEDATE:' , '\n' ) . replace ( ' ' , '-' )
     IIi1i11111 = re . compile ( '-.*?-.*?-(.*?)-' , re . DOTALL ) . findall ( IIi1i11111 )
     ooOO00O00oo = tools . regex_from_to ( iii11 , 'DURATION_SECS:' , '\n' )
     I1ii11iI = tools . regex_from_to ( iii11 , 'GENRE:' , '\n' )
     tools . addDirMeta ( str ( OoOO00O ) . replace ( '[/COLOR].' , '.[/COLOR]' ) , url , 4 , I1ii1Ii1 , i11iiII , oO0o0OOOO , str ( IIi1i11111 ) . replace ( "['" , "" ) . replace ( "']" , "" ) , str ( O0O0OoOO0 ) . split ( ) , iiiI1I11i1 , ooOO00O00oo , I1ii11iI )
    except : pass
    xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'tvshows' )
   else :
    OoOO00O = tools . regex_from_to ( iIi1i111II , '<title>' , '</title>' )
    OoOO00O = base64 . b64decode ( OoOO00O )
    I1ii1Ii1 = tools . regex_from_to ( iIi1i111II , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    url = tools . regex_from_to ( iIi1i111II , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    iii11 = tools . regex_from_to ( iIi1i111II , '<description>' , '</description>' )
    tools . addDir ( OoOO00O , url , 4 , I1ii1Ii1 , i11iiII , base64 . b64decode ( iii11 ) )
    if 84 - 84: i1111
    if 86 - 86: OOooOOo - II1Ii1iI1i - ii1IiI1i * IIii11I1
def oooo0O0 ( ) :
 oOOO = "%s/xmltv.php?username=%s&password=%s" % ( o0oOo0Ooo0O , O0O , Oo )
 try :
  iIII1 = urllib2 . urlopen ( oOOO )
  print iIII1 . getcode ( )
  iIII1 . close ( )
  if 65 - 65: O0
  pass
  if 68 - 68: ooO0oo0oO0 % i1IIi11111i
 except urllib2 . HTTPError , ooO00OO0 :
  print ooO00OO0 . getcode ( )
  IiII . ok ( "[COLOR yellow]Expired Account[/COLOR]" , '[COLOR yellow]You cannot use this service with an expired account[/COLOR]' , ' ' , '[COLOR yellow]Please check your account information[/COLOR]' )
  sys . exit ( 1 )
  xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
  if 31 - 31: IIii11I1 % IIii11I1 % i111I
 OOOOoo0Oo = "%s/xmltv.php?username=%s&password=%s" % ( o0oOo0Ooo0O , O0O , Oo )
 ii111iI1iIi1 ( OOOOoo0Oo , o0oo0o0O00OO + "uide.xml" )
 if 78 - 78: ii1IiI1i . ooO0oo0oO0 + ii1IiI1i / i111I / ii1IiI1i
 IIi = open ( o0o0oOOOo0oo , 'r+' )
 input = open ( o0o0oOOOo0oo ) . read ( ) . decode ( 'UTF-8' )
 oO0O00OoOO0 = unicodedata . normalize ( 'NFKD' , input ) . encode ( 'ASCII' , 'ignore' )
 IIi . write ( oO0O00OoOO0 )
 IIi . truncate ( )
 IIi . close ( )
 OoO ( )
 if 88 - 88: IIii11I1 . II111iiii * II111iiii % i1IIi11111i
def OoO ( ) :
 open = tools . OPEN_URL ( OO0o )
 all = tools . regex_get_all ( open , '{"num' , 'direct' )
 for iIi1i111II in all :
  if '"tv_archive":1' in iIi1i111II :
   OoOO00O = tools . regex_from_to ( iIi1i111II , '"epg_channel_id":"' , '"' )
   I1ii1Ii1 = tools . regex_from_to ( iIi1i111II , '"stream_icon":"' , '"' ) . replace ( '\/' , '/' )
   id = tools . regex_from_to ( iIi1i111II , 'stream_id":"' , '"' )
   tools . addDir ( OoOO00O . replace ( 'ENT:' , '[COLOR white]ENT:[/COLOR]' ) . replace ( 'DOC:' , '[COLOR white]DOC:[/COLOR]' ) . replace ( 'MOV:' , '[COLOR white]MOV:[/COLOR]' ) . replace ( 'SSS:' , '[COLOR white]SSS[/COLOR]' ) . replace ( 'BTS:' , '[COLOR white]BTS:[/COLOR]' ) . replace ( 'TEST' , '[COLOR white]TEST[/COLOR]' ) . replace ( 'Install' , '[COLOR white]Install[/COLOR]' ) . replace ( '24/7' , '[COLOR white]24/7[/COLOR]' ) . replace ( 'INT:' , '[COLOR white]INT:[/COLOR]' ) . replace ( 'DE:' , '[COLOR white]DE:[/COLOR]' ) . replace ( 'FR:' , '[COLOR white]FR:[/COLOR]' ) . replace ( 'PL:' , '[COLOR white]PL:[/COLOR]' ) . replace ( 'AR:' , '[COLOR white]AR:[/COLOR]' ) . replace ( 'LIVE:' , '[COLOR white]LIVE:[/COLOR]' ) . replace ( 'ES:' , '[COLOR white]ES:[/COLOR]' ) . replace ( 'IN:' , '[COLOR white]IN:[/COLOR]' ) . replace ( 'PK:' , '[COLOR white]PK:[/COLOR]' ) , 'url' , 13 , I1ii1Ii1 , i11iiII , id )
   if 15 - 15: i1IIi * o0 + i11iIiiIii
   if 6 - 6: I11i1i11i1I / i11iIiiIii + IIii11I1 * oooO0oo0oOOOO
def o00o0 ( name , description ) :
 name = str ( name . replace ( '[COLOR white]ENT:[/COLOR]' , 'ENT:' ) . replace ( '[COLOR white]DOC:[/COLOR]' , 'DOC:' ) . replace ( '[COLOR white]MOV:[/COLOR]' , 'MOV' ) . replace ( '[COLOR white]SSSS[/COLOR]' , 'SSS:' ) . replace ( '[COLOR white]BTS:[/COLOR]' , 'BTS:' ) . replace ( '[COLOR white]INT:[/COLOR]' , 'INT:' ) . replace ( '[COLOR white]DE:[/COLOR]' , 'DE:' ) . replace ( '[COLOR white]FR:[/COLOR]' , 'FR:' ) . replace ( '[COLOR white]PL:[/COLOR]' , 'PL:' ) . replace ( '[COLOR white]AR:[/COLOR]' , 'AR:' ) . replace ( '[COLOR white]LIVE:[/COLOR]' , 'LIVE:' ) . replace ( '[COLOR white]ES:[/COLOR]' , 'ES:' ) . replace ( '[COLOR white]IN:[/COLOR]' , 'IN:' ) . replace ( '[COLOR white]PK:[/COLOR]' , 'PK' ) )
 ii = open ( o0o0oOOOo0oo )
 OOooooO0Oo = ElementTree . parse ( ii )
 OO = "apples"
 import datetime as dt
 from datetime import time
 iIiIIi1 = datetime . datetime . now ( ) - datetime . timedelta ( days = 5 )
 I1IIII1i = str ( iIiIIi1 )
 I1I11i = str ( datetime . datetime . now ( ) ) . replace ( '-' , '' ) . replace ( ':' , '' ) . replace ( ' ' , '' )
 Ii1I1I1i1Ii = OOooooO0Oo . findall ( "programme" )
 for i1Oo0oO00o in Ii1I1I1i1Ii :
  if name in i1Oo0oO00o . attrib . get ( 'channel' ) :
   i11I1II1I11i = i1Oo0oO00o . attrib . get ( 'start' )
   OooOoOO0 , iI1i11iII111 , Iii1IIII11I = i11I1II1I11i . partition ( ' +' )
   I1IIII1i = str ( I1IIII1i ) . replace ( '-' , '' ) . replace ( ':' , '' ) . replace ( ' ' , '' )
   IIi1i11111 , OOOoo0OO , oO0o0 = i11I1II1I11i . partition ( '2017' )
   iI1Ii11iIiI1 = i1Oo0oO00o . find ( 'title' ) . text + i11I1II1I11i
   oO0o0 = oO0o0 [ : - 6 ]
   if OooOoOO0 > I1IIII1i :
    if OooOoOO0 < I1I11i :
     OO0Oooo0oOO0O = OooOoOO0
     OO0Oooo0oOO0O = OO0Oooo0oOO0O [ : 4 ] + '/' + OO0Oooo0oOO0O [ 4 : ]
     OooOoOO0 = OooOoOO0 [ : 4 ] + '-' + OooOoOO0 [ 4 : ]
     OO0Oooo0oOO0O = OO0Oooo0oOO0O [ : 7 ] + '/' + OO0Oooo0oOO0O [ 7 : ]
     OooOoOO0 = OooOoOO0 [ : 7 ] + '-' + OooOoOO0 [ 7 : ]
     OO0Oooo0oOO0O = OO0Oooo0oOO0O [ : 10 ] + ' - ' + OO0Oooo0oOO0O [ 10 : ]
     OooOoOO0 = OooOoOO0 [ : 10 ] + ':' + OooOoOO0 [ 10 : ]
     OO0Oooo0oOO0O = OO0Oooo0oOO0O [ : 15 ] + ':' + OO0Oooo0oOO0O [ 15 : ]
     OooOoOO0 = OooOoOO0 [ : 13 ] + '-' + OooOoOO0 [ 13 : ]
     OO0Oooo0oOO0O = OO0Oooo0oOO0O [ : - 2 ]
     OooOoOO0 = OooOoOO0 [ : - 2 ]
     o00O0 = ( "%s/streaming/timeshift.php?username=%s&password=%s&stream=%s&start=" ) % ( o0oOo0Ooo0O , O0O , Oo , description )
     OO = o00O0 + str ( OooOoOO0 ) + "&duration=240"
     OO0Oooo0oOO0O = '[COLOR yellow]%s - [/COLOR]' % OO0Oooo0oOO0O
     iI1Ii11iIiI1 = str ( OO0Oooo0oOO0O ) + i1Oo0oO00o . find ( 'title' ) . text
     iii11 = i1Oo0oO00o . find ( 'desc' ) . text
     tools . addDir ( iI1Ii11iIiI1 , OO , 4 , O0OoOoo00o , i11iiII , iii11 )
     xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'episodes' )
     if 83 - 83: I11i1i11i1I
     if 65 - 65: o0 % II1Ii1iI1i * oooO0oo0oOOOO
def ii111iI1iIi1 ( url , dest ) :
 I1iiiii = xbmcgui . DialogProgress ( )
 I1iiiii . create ( 'Fetching latest Catch Up' , "Fetching latest Catch Up..." , ' ' , ' ' )
 I1iiiii . update ( 0 )
 o00oOOooOOo0o = time . time ( )
 urllib . urlretrieve ( url , dest , lambda O0O0ooOOO , oOOo0O00o , iIiIi11 : OOO ( O0O0ooOOO , oOOo0O00o , iIiIi11 , I1iiiii , o00oOOooOOo0o ) )
 if 32 - 32: i1IIi / II111iiii . i1
def OOO ( numblocks , blocksize , filesize , dp , start_time ) :
 try :
  oooOo0OOOoo0 = min ( numblocks * blocksize * 100 / filesize , 100 )
  OOoO = float ( numblocks ) * blocksize / ( 1024 * 1024 )
  OO0O000 = numblocks * blocksize / ( time . time ( ) - start_time )
  if OO0O000 > 0 :
   iiIiI1i1 = ( filesize - numblocks * blocksize ) / OO0O000
  else :
   iiIiI1i1 = 0
  OO0O000 = OO0O000 / 1024
  oO0O00oOOoooO = OO0O000 / 1024
  IiIi11iI = float ( filesize ) / ( 1024 * 1024 )
  Oo0O00O000 = '[COLOR yellow]%.02f MB of less than 5MB[/COLOR]' % ( OOoO )
  ooO00OO0 = '[COLOR yellow]Speed:  %.02f Mb/s ' % oO0O00oOOoooO + '[/COLOR]'
  dp . update ( oooOo0OOOoo0 , Oo0O00O000 , ooO00OO0 )
 except :
  oooOo0OOOoo0 = 100
  dp . update ( oooOo0OOOoo0 )
 if dp . iscanceled ( ) :
  IiII = xbmcgui . Dialog ( )
  IiII . ok ( "SMediaAddon" , 'The download was cancelled.' )
  if 3 - 3: II1Ii1iI1i * IiiIII111iI % i111I
  sys . exit ( )
  dp . close ( )
  if 59 - 59: oooO0oo0oOOOO - IIii11I1
  if 15 - 15: i1IIi11111i . i11iIiiIii . OoooooooOO / ii1IiI1i % II1Ii1iI1i
def OooooOOoo0 ( ) :
 if xbmc . getCondVisibility ( 'System.HasAddon(pvr.iptvsimple)' ) and xbmc . getCondVisibility ( 'System.HasAddon(script.ivueguide)' ) :
  IiII = xbmcgui . Dialog ( ) . select ( 'Select a TV Guide' , [ 'PVR TV Guide' , 'iVue TV Guide' ] )
  if IiII == 0 :
   xbmc . executebuiltin ( 'ActivateWindow(TVGuide)' )
  elif IiII == 1 :
   xbmc . executebuiltin ( 'RunAddon(script.ivueguide)' )
 elif not xbmc . getCondVisibility ( 'System.HasAddon(pvr.iptvsimple)' ) and xbmc . getCondVisibility ( 'System.HasAddon(script.ivueguide)' ) :
  xbmc . executebuiltin ( 'RunAddon(script.ivueguide)' )
 elif xbmc . getCondVisibility ( 'System.HasAddon(pvr.iptvsimple)' ) and not xbmc . getCondVisibility ( 'System.HasAddon(script.ivueguide)' ) :
  xbmc . executebuiltin ( 'ActivateWindow(TVGuide)' )
def i1I1IiiIi1i ( url ) :
 url = str ( url ) . replace ( 'USERNAME' , O0O ) . replace ( 'PASSWORD' , Oo )
 iiI11ii1I1 = xbmcgui . ListItem ( '' , iconImage = 'DefaultVideo.png' , thumbnailImage = O0OoOoo00o )
 iiI11ii1I1 . setInfo ( type = 'Video' , infoLabels = { 'Title' : '' , 'Plot' : '' } )
 iiI11ii1I1 . setProperty ( 'IsPlayable' , 'true' )
 iiI11ii1I1 . setPath ( str ( url ) )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiI11ii1I1 )
 if 82 - 82: II111iiii % i111I / ii1IiI1i + OOooOOo / I11iIi1I / i1IIi11111i
 if 70 - 70: oooO0oo0oOOOO
def oOOoO0o0oO ( ) :
 o0Oo0oO0oOO00 = control . inputDialog ( heading = 'Search SMediaAddon' )
 if o0Oo0oO0oOO00 == "" :
  return
 else :
  return o0Oo0oO0oOO00
  if 92 - 92: OoooooooOO * i1IIi11111i
  if 100 - 100: i1IIi11111i + i1IIi11111i * i1111
def o0Oo0oO0oOO00 ( ) :
 if I1i == 3 :
  return False
 O00Oooo = oOOoO0o0oO ( )
 if not O00Oooo :
  xbmc . executebuiltin ( "XBMC.Notification([COLOR red][B]Search is Empty[/B][/COLOR],Aborting search,4000," + O0OoOoo00o + ")" )
  return
 xbmc . log ( str ( O00Oooo ) )
 open = tools . OPEN_URL ( II11iiii1Ii )
 i11I = tools . regex_get_all ( open , '{"num":' , 'epg' )
 for iIi1i111II in i11I :
  OoOO00O = tools . regex_from_to ( iIi1i111II , 'name":"' , '"' ) . replace ( '\/' , '/' )
  OOOOoo0Oo = tools . regex_from_to ( iIi1i111II , '"stream_id":"' , '"' )
  I1ii1Ii1 = tools . regex_from_to ( iIi1i111II , 'stream_icon":"' , '"' ) . replace ( '\/' , '/' )
  if O00Oooo in OoOO00O . lower ( ) :
   tools . addDir ( OoOO00O , Ooo + OOOOoo0Oo + '.ts' , 4 , I1ii1Ii1 , i11iiII , '' )
  elif O00Oooo not in OoOO00O . lower ( ) and O00Oooo in OoOO00O :
   tools . addDir ( OoOO00O , Ooo + OOOOoo0Oo + '.ts' , 4 , I1ii1Ii1 , i11iiII , '' )
   if 76 - 76: i1111 * IIii11I1
def ooooooo00o ( url ) :
 o0oooOO00 = i1i1II . open ( url ) . read ( )
 if 32 - 32: i1IIi11111i
 try :
  Iii1 = re . findall ( r'<a .*?>(.*?)</a>' , o0oooOO00 )
  oOOOoo00 = re . findall ( r'<a.*?href="(.*?)">' , o0oooOO00 )
  if 9 - 9: O0 % O0 - I11iIi1I
  for OoOiiI1IIIi in oOOOoo00 :
   if '.gif' in OoOiiI1IIIi :
    pass
   if '.srt' in OoOiiI1IIIi :
    pass
   elif '..' in OoOiiI1IIIi :
    pass
   elif '.txt' in OoOiiI1IIIi :
    pass
   elif '.nfo' in OoOiiI1IIIi :
    pass
   elif '.jpg' in OoOiiI1IIIi :
    pass
   elif '1-Irani/' in OoOiiI1IIIi :
    pass
   elif 'index.php' in OoOiiI1IIIi :
    pass
   elif '.png' in OoOiiI1IIIi :
    pass
   elif '?C=M&O=D' in OoOiiI1IIIi :
    pass
   elif '?C=M&O=A' in OoOiiI1IIIi :
    pass
   elif '?C=N&O=D' in OoOiiI1IIIi :
    pass
   elif '?C=N&O=A' in OoOiiI1IIIi :
    pass
   elif '?C=S&O=A' in OoOiiI1IIIi :
    pass
   elif '?C=S&O=D' in OoOiiI1IIIi :
    pass
   elif '?C=N;O=D' in OoOiiI1IIIi :
    pass
   elif '?C=M;O=A' in OoOiiI1IIIi :
    pass
   elif '?C=S;O=A' in OoOiiI1IIIi :
    pass
   elif '?C=D;O=A' in OoOiiI1IIIi :
    pass
   elif 'Torrent' in OoOiiI1IIIi :
    pass
   elif 'exe' in OoOiiI1IIIi :
    pass
   elif 'public' in OoOiiI1IIIi :
    pass
   elif '?C=D;O=A' in OoOiiI1IIIi :
    pass
   elif 'pub' in OoOiiI1IIIi :
    pass
   elif 'install' in OoOiiI1IIIi :
    pass
   elif '?C=D;O=A' in OoOiiI1IIIi :
    pass
   elif '?C=D;O=A' in OoOiiI1IIIi :
    pass
   elif '.m3u' in OoOiiI1IIIi :
    pass
   elif '?C=D;O=A' in OoOiiI1IIIi :
    pass
   elif 'mpeg' in OoOiiI1IIIi :
    pass
   elif '.doc' in OoOiiI1IIIi :
    pass
   elif '.html' in OoOiiI1IIIi :
    pass
   elif 'boss' in OoOiiI1IIIi :
    pass
   else :
    OoOO00O = OoOiiI1IIIi
    if 'txt' in OoOO00O :
     pass
    if '.' in OoOO00O :
     OoOO00O = OoOO00O . replace ( '.' , ' ' )
    if '_' in OoOO00O :
     OoOO00O = OoOO00O . replace ( '_' , ' ' )
    if '%20' in OoOO00O :
     OoOO00O = OoOO00O . replace ( '%20' , ' ' )
    if '/' in OoOO00O :
     OoOO00O = OoOO00O . replace ( '/' , '' )
    if 'mkv' in OoOO00O :
     OoOO00O = OoOO00O . replace ( 'mkv' , '' )
    if 'avi' in OoOO00O :
     OoOO00O = OoOO00O . replace ( 'avi' , '' )
    if 'mp4' in OoOO00O :
     OoOO00O = OoOO00O . replace ( 'mp4' , '' )
     if 47 - 47: i1 % i111I % i11iIiiIii - O0 + I11i1i11i1I
     if 94 - 94: i1IIi11111i
    if '.mkv' in OoOiiI1IIIi or '.m4B' in OoOiiI1IIIi or '.m4v' in OoOiiI1IIIi or '.mp3' in OoOiiI1IIIi or '.mp4' in OoOiiI1IIIi or '.avi' in OoOiiI1IIIi or '.flv' in OoOiiI1IIIi or '.mpeg' in OoOiiI1IIIi or '.3gp' in OoOiiI1IIIi or '.divx' in OoOiiI1IIIi or '.strm' in OoOiiI1IIIi :
     i11II1I11I1 ( '[COLORsteelblue]' + OoOO00O + '[/COLOR]' , url + OoOiiI1IIIi , 222 , ART + 'boss.png' , 'GenieTv does not host or distribute any of the content displayed by this addon. GenieTV does not have any affiliation with the content provider.' , isFolder = False )
     if 67 - 67: o0 - I11iIi1I / i111I - i1IIi
    else :
     i11II1I11I1 ( '[COLORsteelblue]' + OoOO00O + '[/COLOR]' , url + OoOiiI1IIIi , 2032 , ART + 'boss.png' , '' , isFolder = True )
     if 1 - 1: II111iiii
     if 68 - 68: IIii11I1 - o0 / i1IIi11111i / i111I
     if 12 - 12: II1Ii1iI1i + i11iIiiIii * iIii1I11I1II1 / IiiIII111iI . i111I
     if 5 - 5: i1IIi + i1111 / I11iIi1I . IIii11I1 / i111I
 except Exception , ooO00OO0 :
  print str ( ooO00OO0 )
  if 32 - 32: o0 % iIii1I11I1II1 / i1IIi - o0
def i11II1I11I1 ( name , url , mode , iconimage , description = "" , isFolder = True , background = None ) :
 I1III1111iIi = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 if 38 - 38: IIii11I1 + i111I / i1IIi11111i % I11i1i11i1I - IiiIII111iI
 iiI11ii1I1 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 iiI11ii1I1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 if background :
  iiI11ii1I1 . setProperty ( 'fanart_image' , background )
 if mode == 1 or mode == 2 :
  iiI11ii1I1 . addContextMenuItems ( items = [ ( '{0}' . format ( localizedString ( 10008 ) . encode ( 'utf-8' ) ) , 'XBMC.RunPlugin({0}?url={1}&mode=22)' . format ( sys . argv [ 0 ] , urllib . quote_plus ( url ) ) ) ] )
 elif mode == 404 :
  iiI11ii1I1 . setProperty ( 'IsPlayable' , 'true' )
  iiI11ii1I1 . addContextMenuItems ( items = [ ( '{0}' . format ( localizedString ( 10009 ) . encode ( 'utf-8' ) ) , 'XBMC.RunPlugin({0}?url={1}&mode=31&iconimage={2}&name={3})' . format ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , iconimage , name ) ) ] )
 elif mode == 556 :
  iiI11ii1I1 . setProperty ( 'IsPlayable' , 'true' )
  iiI11ii1I1 . addContextMenuItems ( items = [ ( '{0}' . format ( localizedString ( 10010 ) . encode ( 'utf-8' ) ) , 'XBMC.RunPlugin({0}?url={1}&mode=33&iconimage={2}&name={3})' . format ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , iconimage , name ) ) ] )
  if 14 - 14: oooO0oo0oOOOO / i1IIi11111i
 xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1III1111iIi , listitem = iiI11ii1I1 , isFolder = isFolder )
def ooo0O0o00O ( name , url , mode , iconimage , fanart , description ) :
 if 48 - 48: I11i1i11i1I / i1IIi11111i . iIii1I11I1II1 * OOooOOo * oooO0oo0oOOOO / i1IIi
 I1III1111iIi = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&description=" + urllib . quote_plus ( description )
 OOOOoOOo0O0 = True
 iiI11ii1I1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 iiI11ii1I1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 iiI11ii1I1 . setProperty ( "Fanart_Image" , fanart )
 OOOOoOOo0O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1III1111iIi , listitem = iiI11ii1I1 , isFolder = False )
 return OOOOoOOo0O0
 if 92 - 92: IiiIII111iI + iIii1I11I1II1 / II111iiii
def OooO0OOo0OOo0o0O0O ( ) :
 tools . addDir ( 'Edit Advanced Settings' , 'ADS' , 10 , O0OoOoo00o , i11iiII , '' )
 tools . addDir ( 'Log Out' , 'LO' , 10 , O0OoOoo00o , i11iiII , '' )
 if 65 - 65: i11iIiiIii
 if 85 - 85: II1Ii1iI1i % IIii11I1 + i111I / I11iIi1I . oooO0oo0oOOOO + ooO0oo0oO0
def Ooo0OO0oOO ( url , description ) :
 if url == "CC" :
  tools . clear_cache ( )
 elif url == "AS" :
  xbmc . executebuiltin ( 'Addon.OpenSettings(%s)' % IiII1IiiIiI1 )
 elif url == "ADS" :
  IiII = xbmcgui . Dialog ( ) . select ( 'Edit Advanced Settings' , [ 'Enable Fire TV Stick AS' , 'Enable Fire TV AS' , 'Enable 1GB Ram or Lower AS' , 'Enable 2GB Ram or Higher AS' , 'Enable Nvidia Shield AS' , 'Disable AS' ] )
  if IiII == 0 :
   ooOoOo0 ( 'stick' )
   xbmcgui . Dialog ( ) . ok ( 'SMediaAddon' , 'Set Advanced Settings' )
  elif IiII == 1 :
   ooOoOo0 ( 'firetv' )
   xbmcgui . Dialog ( ) . ok ( 'SMediaAddon' , 'Set Advanced Settings' )
  elif IiII == 2 :
   ooOoOo0 ( 'lessthan' )
   xbmcgui . Dialog ( ) . ok ( 'SMediaAddon' , 'Set Advanced Settings' )
  elif IiII == 3 :
   ooOoOo0 ( 'morethan' )
   xbmcgui . Dialog ( ) . ok ( 'SMediaAddon' , 'Set Advanced Settings' )
  elif IiII == 4 :
   ooOoOo0 ( 'shield' )
   xbmcgui . Dialog ( ) . ok ( 'SMediaAddon' , 'Set Advanced Settings' )
  elif IiII == 5 :
   ooOoOo0 ( 'remove' )
   xbmcgui . Dialog ( ) . ok ( 'SMediaAddon' , 'Advanced Settings Removed' )
 elif url == "ADS2" :
  IiII = xbmcgui . Dialog ( ) . select ( 'Select Your Device Or Closest To' , [ 'Fire TV Stick ' , 'Fire TV' , '1GB Ram or Lower' , '2GB Ram or Higher' , 'Nvidia Shield' ] )
  if IiII == 0 :
   ooOoOo0 ( 'stick' )
   xbmcgui . Dialog ( ) . ok ( 'SMediaAddon' , 'Set Advanced Settings' )
  elif IiII == 1 :
   ooOoOo0 ( 'firetv' )
   xbmcgui . Dialog ( ) . ok ( 'SMediaAddon' , 'Set Advanced Settings' )
  elif IiII == 2 :
   ooOoOo0 ( 'lessthan' )
   xbmcgui . Dialog ( ) . ok ( 'SMediaAddon' , 'Set Advanced Settings' )
  elif IiII == 3 :
   ooOoOo0 ( 'morethan' )
   xbmcgui . Dialog ( ) . ok ( 'SMediaAddon' , 'Set Advanced Settings' )
  elif IiII == 4 :
   ooOoOo0 ( 'shield' )
   xbmcgui . Dialog ( ) . ok ( 'SMediaAddon' , 'Set Advanced Settings' )
 elif url == "tv" :
  I11iiiiI1i ( )
 elif url == "ST" :
  xbmc . executebuiltin ( 'Runscript("special://home/addons/SMediaAddon/resources/modules/speedtest.py")' )
 elif url == "META" :
  if 'ON' in description :
   xbmcaddon . Addon ( ) . setSetting ( 'meta' , 'false' )
   xbmc . executebuiltin ( 'Container.Refresh' )
  else :
   xbmcaddon . Addon ( ) . setSetting ( 'meta' , 'true' )
   xbmc . executebuiltin ( 'Container.Refresh' )
 elif url == "LO" :
  xbmcaddon . Addon ( ) . setSetting ( 'Username' , '' )
  xbmcaddon . Addon ( ) . setSetting ( 'Password' , '' )
  xbmc . executebuiltin ( 'XBMC.ActivateWindow(Videos,addons://sources/video/)' )
  xbmc . executebuiltin ( 'Container.Refresh' )
 elif url == "UPDATE" :
  if 'ON' in description :
   xbmcaddon . Addon ( ) . setSetting ( 'update' , 'false' )
   xbmc . executebuiltin ( 'Container.Refresh' )
  else :
   xbmcaddon . Addon ( ) . setSetting ( 'update' , 'true' )
   xbmc . executebuiltin ( 'Container.Refresh' )
   if 40 - 40: IiiIII111iI + i1IIi * ooO0oo0oO0
   if 85 - 85: II1Ii1iI1i * i1 . O0 - i11iIiiIii
def ooOoOo0 ( device ) :
 if device == 'stick' :
  file = open ( os . path . join ( oOOO0o0o , 'stick.xml' ) )
 elif device == 'firetv' :
  file = open ( os . path . join ( oOOO0o0o , 'firetv.xml' ) )
 elif device == 'lessthan' :
  file = open ( os . path . join ( oOOO0o0o , 'lessthan1GB.xml' ) )
 elif device == 'morethan' :
  file = open ( os . path . join ( oOOO0o0o , 'morethan1GB.xml' ) )
 elif device == 'shield' :
  file = open ( os . path . join ( oOOO0o0o , 'shield.xml' ) )
 elif device == 'remove' :
  os . remove ( iiI1 )
  if 18 - 18: II1Ii1iI1i + i1111 - O0
 try :
  o00Oi1Ii1i1I11Iii = file . read ( )
  IIi = open ( iiI1 , mode = 'w+' )
  IIi . write ( o00Oi1Ii1i1I11Iii )
  IIi . close ( )
 except :
  pass
  if 25 - 25: i1111 + II1Ii1iI1i / I11i1i11i1I . I11iIi1I % O0 * ii1IiI1i
  if 84 - 84: I11i1i11i1I % II1Ii1iI1i + i11iIiiIii
def I11iiiiI1i ( ) :
 II1I1Ii ( )
 return
 if 62 - 62: O0 % i111I . i111I - iIii1I11I1II1 / i11iIiiIii
 if 31 - 31: iIii1I11I1II1 / ii1IiI1i / IiiIII111iI
def iiIiIi ( ) :
 i11IiIiiIiII = xbmcgui . Dialog ( ) . yesno ( 'SMediaAddon' , 'Please Select The RAM Size of Your Device' , yeslabel = 'Less than 1GB RAM' , nolabel = 'More than 1GB RAM' )
 if i11IiIiiIiII :
  iiIIi ( )
 else :
  iiI1iI111ii1i ( )
  if 32 - 32: II111iiii * OOooOOo % i1IIi - IIii11I1 + iIii1I11I1II1 + IiiIII111iI
  if 60 - 60: IiiIII111iI % OOooOOo * ii1IiI1i % II111iiii
def iiI1iI111ii1i ( ) :
 file = open ( os . path . join ( oOOO0o0o , 'morethan.xml' ) )
 iIi1i111II = file . read ( )
 IIi = open ( iiI1 , mode = 'w+' )
 IIi . write ( iIi1i111II )
 IIi . close ( )
 if 70 - 70: ii1IiI1i % oooO0oo0oOOOO + ooO0oo0oO0 / II1Ii1iI1i % O0
 if 100 - 100: I11iIi1I + ooO0oo0oO0 * I11iIi1I
def iiIIi ( ) :
 file = open ( os . path . join ( oOOO0o0o , 'lessthan.xml' ) )
 iIi1i111II = file . read ( )
 IIi = open ( iiI1 , mode = 'w+' )
 IIi . write ( iIi1i111II )
 IIi . close ( )
 if 80 - 80: I11iIi1I * O0 - II1Ii1iI1i
 if 66 - 66: i11iIiiIii - ooO0oo0oO0 * i1
def iiiIi1i1I ( ) :
 OooOOOO = xbmc . Keyboard ( '' , 'heading' , True )
 OooOOOO . setHeading ( 'Enter Username' )
 OooOOOO . setHiddenInput ( False )
 OooOOOO . doModal ( )
 if ( OooOOOO . isConfirmed ( ) ) :
  O00Oooo = OooOOOO . getText ( )
  return O00Oooo
 else :
  return False
  if 45 - 45: IiiIII111iI % o0 - i11iIiiIii
  if 11 - 11: iIii1I11I1II1 * iIii1I11I1II1 * o0
def OoOo ( ) :
 OooOOOO = xbmc . Keyboard ( '' , 'heading' , True )
 OooOOOO . setHeading ( 'Enter Password' )
 OooOOOO . setHiddenInput ( False )
 OooOOOO . doModal ( )
 if ( OooOOOO . isConfirmed ( ) ) :
  O00Oooo = OooOOOO . getText ( )
  return O00Oooo
 else :
  return False
  if 46 - 46: OOooOOo + ii1IiI1i
  if 70 - 70: IIii11I1 / iIii1I11I1II1
def Oo0oooO0oO ( ) :
 open = tools . OPEN_URL ( II11iiii1Ii )
 try :
  O0O = tools . regex_from_to ( open , '"username":"' , '",' )
  Oo = tools . regex_from_to ( open , '"password":"' , '"' )
  IiIiII1 = tools . regex_from_to ( open , '"status":"' , '"' )
  Iii1iiIi1II = tools . regex_from_to ( open , '"max_connections":"' , '"' )
  OO0O00oOo = tools . regex_from_to ( open , '"active_cons":"' , '"' )
  ii1II = tools . regex_from_to ( open , '"exp_date":"' , '"' )
  ii1II = datetime . datetime . fromtimestamp ( int ( ii1II ) ) . strftime ( '%d/%m/%Y - %H:%M' )
  iI1I = re . compile ( '^(.*?)/(.*?)/(.*?)$' , re . DOTALL ) . findall ( ii1II )
  for oO0o0 , OOOoo0OO , IIi1i11111 in iI1I :
   OOOoo0OO = tools . MonthNumToName ( OOOoo0OO )
   IIi1i11111 = re . sub ( ' -.*?$' , '' , IIi1i11111 )
   ii1II = OOOoo0OO + ' ' + oO0o0 + ' - ' + IIi1i11111
   OooOoOo = tools . getlocalip ( )
   III1I1Iii1iiI = tools . getexternalip ( )
   tools . addDir ( '[COLOR yellow]Username :[/COLOR] ' + O0O , '' , '' , O0OoOoo00o , i11iiII , '' )
   tools . addDir ( '[COLOR yellow]Password :[/COLOR] ' + Oo , '' , '' , O0OoOoo00o , i11iiII , '' )
   tools . addDir ( '[COLOR yellow]Expiry Date:[/COLOR] ' + ii1II , '' , '' , O0OoOoo00o , i11iiII , '' )
   tools . addDir ( '[COLOR yellow]Account Status :[/COLOR] %s' % IiIiII1 , '' , '' , O0OoOoo00o , i11iiII , '' )
   tools . addDir ( '[COLOR yellow]Current Connections:[/COLOR] ' + OO0O00oOo , '' , '' , O0OoOoo00o , i11iiII , '' )
   tools . addDir ( '[COLOR yellow]Allowed Connections:[/COLOR] ' + Iii1iiIi1II , '' , '' , O0OoOoo00o , i11iiII , '' )
   tools . addDir ( '[COLOR yellow]Local IP Address:[/COLOR] ' + OooOoOo , '' , '' , O0OoOoo00o , i11iiII , '' )
   tools . addDir ( '[COLOR yellow]External IP Address:[/COLOR] ' + III1I1Iii1iiI , '' , '' , O0OoOoo00o , i11iiII , '' )
 except : pass
 if 17 - 17: II1Ii1iI1i % iIii1I11I1II1 - iIii1I11I1II1
 if 78 - 78: IIii11I1 + i111I . I11i1i11i1I - IIii11I1 . II1Ii1iI1i
def II1I1Ii ( ) :
 if 30 - 30: o0 + ii1IiI1i % II1Ii1iI1i * IIii11I1 / i1 - i111I
 ooo = xbmcaddon . Addon ( 'plugin.video.SMediaAddon' )
 iIi1i = ooo . getSetting ( id = 'Username' )
 I1i11111i1i11 = ooo . getSetting ( id = 'Password' )
 OOoOOO0 = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":true},"id":1}'
 I1I1i = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}'
 I1IIIiIiIi = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.demo","enabled":false},"id":1}'
 oOOO = "%s/get.php?username=%s&password=%s&type=m3u_plus&output=mpegts" % ( o0oOo0Ooo0O , O0O , Oo )
 IIIII1 = "%s/xmltv.php?username=%s&password=%s" % ( o0oOo0Ooo0O , O0O , Oo )
 if 5 - 5: II1Ii1iI1i
 xbmc . executeJSONRPC ( OOoOOO0 )
 xbmc . executeJSONRPC ( I1I1i )
 xbmc . executeJSONRPC ( I1IIIiIiIi )
 if 46 - 46: i1111
 ii1iIi1iIiI1i = xbmcaddon . Addon ( 'pvr.iptvsimple' )
 ii1iIi1iIiI1i . setSetting ( id = 'm3uUrl' , value = oOOO )
 ii1iIi1iIiI1i . setSetting ( id = 'epgUrl' , value = IIIII1 )
 ii1iIi1iIiI1i . setSetting ( id = 'm3uCache' , value = "false" )
 ii1iIi1iIiI1i . setSetting ( id = 'epgCache' , value = "false" )
 xbmc . executebuiltin ( "Container.Refresh" )
 if 40 - 40: i1IIi % ooO0oo0oO0
def ooo0o00 ( ) :
 ivuesetup . iVueInt ( )
 if 99 - 99: O0 . i111I + iIii1I11I1II1
def iiii11I ( ) :
 IiII = xbmcgui . Dialog ( ) . yesno ( 'SMediaAddon' , 'Would You like us to Setup the PVR Guide for You?' )
 if IiII :
  IiII = xbmcgui . Dialog ( ) . select ( 'Select PVR To Setup' , [ 'PVR TV Guide' ] )
  if IiII == 0 :
   I11iiiiI1i ( )
   xbmcgui . Dialog ( ) . ok ( 'SMediaAddon' , 'PVR Integration Complete' )
  elif IiII == 1 :
   I11iiiiI1i ( )
   xbmcgui . Dialog ( ) . ok ( 'SMediaAddon' , 'PVR Integration Complete' )
  elif IiII == 2 :
   I11iiiiI1i ( )
   ooo0o00 ( )
   xbmcgui . Dialog ( ) . ok ( 'SMediaAddon' , 'PVR & iVue Integration Complete' )
   if 32 - 32: II1Ii1iI1i . iIii1I11I1II1 % iIii1I11I1II1 * i11iIiiIii - ii1IiI1i - i111I
def o00oo0 ( num ) :
 if num == "0" :
  oO0o0 = 'monday'
 elif num == "1" :
  oO0o0 = 'tuesday'
 elif num == "2" :
  oO0o0 = 'wednesday'
 elif num == "3" :
  oO0o0 = 'thursday'
 elif num == "4" :
  oO0o0 = 'friday'
 elif num == "5" :
  oO0o0 = 'saturday'
 elif num == "6" :
  oO0o0 = 'sunday'
 return oO0o0
 if 59 - 59: o0 * II111iiii . O0
def O000OoOO0 ( ) :
 tools . addDir ( 'Create a Short M3U & EPG URL' , 'url' , 17 , O0OoOoo00o , i11iiII , '' )
 tools . addDir ( 'Integrate With TV Guide' , 'tv' , 10 , O0OoOoo00o , i11iiII , '' )
 tools . addDir ( 'Run a Speed Test' , 'ST' , 10 , O0OoOoo00o , i11iiII , '' )
 tools . addDir ( 'Clear Cache' , 'CC' , 10 , O0OoOoo00o , i11iiII , '' )
 if 30 - 30: i1111
def oOO ( ) :
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 O0o0OO0000ooo = o0oOo0Ooo0O + '%3A8085%2Fget.php%3Fusername%3D' + O0O + '%26password%3D' + Oo + '%26type%3Dm3u_plus%26output%3Dmpegts'
 iIIII1iIIii = o0oOo0Ooo0O + '%3A8085%2Fxmltv.php%3Fusername%3D' + O0O + '%26password%3D' + Oo
 iI = o0oOo0Ooo0O + '/enigma2.php?username=' + O0O + '&password=' + Oo + '&type=get_vod_categories'
 iI = tools . OPEN_URL ( iI )
 if not iI == "" :
  oOOO00o000o = 'https://tinyurl.com/create.php?source=indexpage&url=' + O0o0OO0000ooo + '&submit=Make+TinyURL%21&alias='
  xbmc . log ( str ( oOOO00o000o ) )
  iIi11i1 = 'https://tinyurl.com/create.php?source=indexpage&url=' + iIIII1iIIii + '&submit=Make+TinyURL%21&alias='
  O0o0OO0000ooo = tools . OPEN_URL ( oOOO00o000o )
  iIIII1iIIii = tools . OPEN_URL ( iIi11i1 )
  xbmc . log ( str ( iIIII1iIIii ) )
  oO00oo0o00o0o = tools . regex_from_to ( O0o0OO0000ooo , '<div class="indent"><b>' , '</b>' )
  IiIIIIIi = tools . regex_from_to ( iIIII1iIIii , '<div class="indent"><b>' , '</b>' )
  xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
  xbmcgui . Dialog ( ) . ok ( 'S_Media' , '[COLOR blue]M3U URL: [/COLOR]%s' % oO00oo0o00o0o , '' , '[COLOR blue]EPG URL: [/COLOR]%s' % IiIIIIIi )
 else :
  return
IiIi1iIIi1 = tools . get_params ( )
OOOOoo0Oo = None
OoOO00O = None
I1i = None
O0OoO0ooOO0o = None
OoOo0oOooOoOO = None
oo00ooOoO00 = None
type = None
if 96 - 96: ooO0oo0oO0
try :
 OOOOoo0Oo = urllib . unquote_plus ( IiIi1iIIi1 [ "url" ] )
except :
 pass
try :
 OoOO00O = urllib . unquote_plus ( IiIi1iIIi1 [ "name" ] )
except :
 pass
try :
 O0OoO0ooOO0o = urllib . unquote_plus ( IiIi1iIIi1 [ "iconimage" ] )
except :
 pass
try :
 I1i = int ( IiIi1iIIi1 [ "mode" ] )
except :
 pass
try :
 OoOo0oOooOoOO = urllib . unquote_plus ( IiIi1iIIi1 [ "description" ] )
except :
 pass
try :
 oo00ooOoO00 = urllib . unquote_plus ( IiIi1iIIi1 [ "query" ] )
except :
 pass
try :
 type = urllib . unquote_plus ( IiIi1iIIi1 [ "type" ] )
except :
 pass
 if 85 - 85: I11iIi1I . OOooOOo / I11i1i11i1I . O0 % i1IIi11111i
if I1i == None or OOOOoo0Oo == None or len ( OOOOoo0Oo ) < 1 :
 ii1I1i1I ( )
 if 90 - 90: i1 % O0 * iIii1I11I1II1 . IIii11I1
elif I1i == 1 :
 IIi1I1Ii11iI ( OOOOoo0Oo )
 if 8 - 8: I11i1i11i1I + II111iiii / IIii11I1 / i111I
elif I1i == 2 :
 i1I11i1iI ( OOOOoo0Oo )
 if 74 - 74: O0 / i1IIi
elif I1i == 3 :
 I1i1IiI1 ( OOOOoo0Oo )
 if 78 - 78: OoooooooOO . ii1IiI1i + I11i1i11i1I - i1IIi
elif I1i == 4 :
 i1I1IiiIi1i ( OOOOoo0Oo )
 if 31 - 31: OoooooooOO . ooO0oo0oO0
elif I1i == 5 :
 o0Oo0oO0oOO00 ( )
 if 83 - 83: IIii11I1 . O0 / i1 / ooO0oo0oO0 - II111iiii
elif I1i == 6 :
 Oo0oooO0oO ( )
 if 100 - 100: ii1IiI1i
elif I1i == 7 :
 OooooOOoo0 ( )
 if 46 - 46: OOooOOo / iIii1I11I1II1 % IIii11I1 . iIii1I11I1II1 * IIii11I1
elif I1i == 8 :
 OooO0OOo0OOo0o0O0O ( )
 if 38 - 38: IiiIII111iI - IIii11I1 / O0 . i1IIi11111i
elif I1i == 9 :
 xbmc . executebuiltin ( 'ActivateWindow(busydialog)' )
 tools . Trailer ( ) . play ( OOOOoo0Oo )
 xbmc . executebuiltin ( 'Dialog.Close(busydialog)' )
 if 45 - 45: i1IIi11111i
elif I1i == 10 :
 Ooo0OO0oOO ( OOOOoo0Oo , OoOo0oOooOoOO )
 if 83 - 83: OOooOOo . OoooooooOO
elif I1i == 11 :
 I11iiiiI1i ( )
 if 58 - 58: i11iIiiIii + OoooooooOO % OoooooooOO / i1111 / i11iIiiIii
elif I1i == 12 :
 oooo0O0 ( )
 if 62 - 62: ii1IiI1i / IiiIII111iI
elif I1i == 13 :
 o00o0 ( OoOO00O , OoOo0oOooOoOO )
 if 7 - 7: OoooooooOO . i1111
elif I1i == 14 :
 listcatchup2 ( )
 if 53 - 53: II1Ii1iI1i % II1Ii1iI1i * I11iIi1I + OOooOOo
elif I1i == 15 :
 ooo0o00 ( )
 if 92 - 92: OoooooooOO + i1IIi / II1Ii1iI1i * O0
elif I1i == 16 :
 O000OoOO0 ( )
 if 100 - 100: I11i1i11i1I % iIii1I11I1II1 * II111iiii - IIii11I1
elif I1i == 17 :
 oOO ( )
 if 92 - 92: I11i1i11i1I
elif I1i == 18 :
 footballguidesearch ( OoOo0oOooOoOO )
 if 22 - 22: i1 % IIii11I1 * IiiIII111iI / ooO0oo0oO0 % i11iIiiIii * i111I
elif I1i == 19 :
 get ( )
 if 95 - 95: OoooooooOO - i1111 * o0 + OOooOOo
elif I1i == 20 :
 ooooooo00o ( OOOOoo0Oo )
 if 10 - 10: I11iIi1I / i11iIiiIii
elif I1i == 21 :
 O0OOO ( )
 if 92 - 92: i111I . i1IIi11111i
elif I1i == 22 :
 II11iIiIIIiI ( )
 if 85 - 85: IiiIII111iI . i1IIi11111i
elif I1i == 23 :
 IIiIiiIi ( )
 if 78 - 78: I11i1i11i1I * i1IIi11111i + iIii1I11I1II1 + iIii1I11I1II1 / i1IIi11111i . II1Ii1iI1i
elif I1i == 24 :
 OOooOoooOoOo ( OOOOoo0Oo )
 if 97 - 97: I11i1i11i1I / i1IIi11111i % i1IIi % IiiIII111iI
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
